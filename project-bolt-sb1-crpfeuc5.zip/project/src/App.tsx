import React, { useState } from 'react';
import * as XLSX from 'xlsx';
import Sentiment from 'sentiment';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, PieChart, Pie, Cell } from 'recharts';
import { FileUp as FileUpload, TrendingUp, TrendingDown, MinusCircle } from 'lucide-react';
import { 
  Box, 
  Card, 
  CardContent, 
  Typography, 
  Grid,
  TextField,
  Select,
  MenuItem,
  FormControl,
  InputLabel
} from '@mui/material';

interface SentimentData {
  text: string;
  score: number;
  comparative: number;
  tokens: string[];
  words: string[];
  positive: string[];
  negative: string[];
}

function App() {
  const [data, setData] = useState<SentimentData[]>([]);
  const [filter, setFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  
  // Initialize sentiment analyzer
  const analyzer = new Sentiment();

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const binaryStr = event.target?.result;
      if (typeof binaryStr !== 'string') return;
      
      const workbook = XLSX.read(binaryStr, { type: 'binary' });
      const sheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[sheetName];
      const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 }) as any[];

      // Analyze sentiment for each row (assuming text is in first column)
      const sentimentResults = jsonData
        .slice(1) // Skip header row
        .filter(row => Array.isArray(row) && row.length > 0 && row[0]) // Ensure row has data
        .map(row => {
          const text = String(row[0]); // Convert to string to ensure valid input
          const analysis = analyzer.analyze(text);
          return {
            text,
            ...analysis
          };
        });

      setData(sentimentResults);
    };
    reader.readAsBinaryString(file);
  };

  const filteredData = data.filter(item => {
    const matchesSearch = item.text.toLowerCase().includes(searchTerm.toLowerCase());
    if (filter === 'all') return matchesSearch;
    if (filter === 'positive') return item.score > 0 && matchesSearch;
    if (filter === 'negative') return item.score < 0 && matchesSearch;
    return item.score === 0 && matchesSearch;
  });

  const sentimentCounts = {
    positive: data.filter(item => item.score > 0).length,
    neutral: data.filter(item => item.score === 0).length,
    negative: data.filter(item => item.score < 0).length
  };

  const pieData = [
    { name: 'Positive', value: sentimentCounts.positive },
    { name: 'Neutral', value: sentimentCounts.neutral },
    { name: 'Negative', value: sentimentCounts.negative }
  ];

  const COLORS = ['#4CAF50', '#FFC107', '#F44336'];

  const averageSentiment = data.length > 0 
    ? (data.reduce((acc, curr) => acc + curr.score, 0) / data.length).toFixed(2)
    : 0;

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-7xl mx-auto">
        <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
          <h1 className="text-3xl font-bold mb-6 text-gray-800">Sentiment Analysis Dashboard</h1>
          
          <div className="mb-8">
            <label className="inline-block px-6 py-3 bg-blue-600 text-white rounded-lg cursor-pointer hover:bg-blue-700 transition-colors">
              <FileUpload className="inline-block mr-2" />
              Upload Excel File
              <input
                type="file"
                accept=".xlsx, .xls"
                onChange={handleFileUpload}
                className="hidden"
              />
            </label>
          </div>

          {data.length > 0 && (
            <>
              <Grid container spacing={4} className="mb-8">
                <Grid item xs={12} md={4}>
                  <Card>
                    <CardContent>
                      <Typography variant="h6" gutterBottom>Average Sentiment</Typography>
                      <Typography variant="h3" className="flex items-center">
                        {averageSentiment}
                        {Number(averageSentiment) > 0 ? (
                          <TrendingUp className="ml-2 text-green-500" />
                        ) : Number(averageSentiment) < 0 ? (
                          <TrendingDown className="ml-2 text-red-500" />
                        ) : (
                          <MinusCircle className="ml-2 text-yellow-500" />
                        )}
                      </Typography>
                    </CardContent>
                  </Card>
                </Grid>
                <Grid item xs={12} md={8}>
                  <Card>
                    <CardContent>
                      <Typography variant="h6" gutterBottom>Sentiment Distribution</Typography>
                      <PieChart width={300} height={200}>
                        <Pie
                          data={pieData}
                          cx={150}
                          cy={100}
                          innerRadius={60}
                          outerRadius={80}
                          fill="#8884d8"
                          dataKey="value"
                          label
                        >
                          {pieData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip />
                        <Legend />
                      </PieChart>
                    </CardContent>
                  </Card>
                </Grid>
              </Grid>

              <div className="mb-6 flex gap-4">
                <FormControl variant="outlined" className="min-w-[200px]">
                  <InputLabel>Filter</InputLabel>
                  <Select
                    value={filter}
                    onChange={(e) => setFilter(e.target.value)}
                    label="Filter"
                  >
                    <MenuItem value="all">All</MenuItem>
                    <MenuItem value="positive">Positive</MenuItem>
                    <MenuItem value="neutral">Neutral</MenuItem>
                    <MenuItem value="negative">Negative</MenuItem>
                  </Select>
                </FormControl>

                <TextField
                  label="Search"
                  variant="outlined"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="flex-1"
                />
              </div>

              <div className="bg-white rounded-lg shadow overflow-hidden">
                <table className="min-w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Text</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Score</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Sentiment</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {filteredData.map((item, index) => (
                      <tr key={index}>
                        <td className="px-6 py-4 whitespace-normal">{item.text}</td>
                        <td className="px-6 py-4">{item.score}</td>
                        <td className="px-6 py-4">
                          {item.score > 0 ? (
                            <span className="text-green-600">Positive</span>
                          ) : item.score < 0 ? (
                            <span className="text-red-600">Negative</span>
                          ) : (
                            <span className="text-yellow-600">Neutral</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

export default App;