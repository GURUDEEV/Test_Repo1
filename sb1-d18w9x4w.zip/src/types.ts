export interface SentimentData {
  nameKey: string;
  nameId: number;
  description: string;
  updatedDate: string;
  sentimentScore: number;
}

export interface KPICard {
  title: string;
  value: number;
  change: number;
  icon: React.ReactNode;
}

export interface ChartData {
  name: string;
  value: number;
}